local _ = require("gettext")
return {
    name = "MyWebDav",
    fullname = _("MyWebDav"),
    description = _([[This plugin starts / stops a WebDav Server.]]),
}
